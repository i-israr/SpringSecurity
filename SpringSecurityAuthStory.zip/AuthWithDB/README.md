For finding the user and to authenticate the user spring security needs the following:
1)	User details service (For finding the user)
2)	Password encoder (For encrypt the password)
3)	Authentication provider (For authenticate the user)

													Authentication Story

We have applied a security on each user’s http request http.authorizeRequests().anyRequest().authenticated() which means each request should be authenticated.

The request is intercepted by the authentication filter and Authentication responsibility is delegated to the authentication manager

For authentication user will be provided with the login page .formLogin().loginPage("/showMyLoginPage")

User enter the name and password.

UserService will use the name of the user (coming from login page) and find the details of the user from the database loadUserByUsername(String username) =>  userRepository.findByUsername(username);

After finding the details of the user (Name, Password, Roles) from the database, UserService will pass the details to the authentication provider 

Now authentication provider use the database details and the user detail (coming from login page), for authentication. 

For authentication, authentication provider use it’s authenticate() method.

For better understanding of how authentication provider works see custom implementation of authenticationProvider in book page no 110

