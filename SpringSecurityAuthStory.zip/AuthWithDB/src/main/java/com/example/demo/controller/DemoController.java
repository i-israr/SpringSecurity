package com.example.demo.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DemoController {

	@PreAuthorize("hasAuthority('ROLE_EMPLOYEE')") 
	@GetMapping("/")
	public String showHome() {
		return "home";
	}

	@GetMapping("/showMyLoginPage")
	public String showMyLoginPage() {
		// return "plain-login";
		return "fancy-login";

	}
	
	@PreAuthorize("hasAuthority('ROLE_MANAGER')") 
	@GetMapping("/leaders")
	public String showLeaders() {

		return "leaders";
	}
	
	@PreAuthorize("hasAuthority('ROLE_ADMIN')") 
	@GetMapping("/systems")
	public String showSystems() {

		return "systems";
	}
	
	@GetMapping("/access-denied")
	public String showAccessDenied() {

		return "access-denied";

	}

}
