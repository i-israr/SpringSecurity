package com.example.demo.service;

import org.springframework.security.core.userdetails.UserDetailsService;
//For retrieving data extend UserService with UserDetailsService
public interface UserService extends UserDetailsService{

}
//The UserDetailsService is only responsible for retrieving the
//user by username. This action is the only one needed by the framework to complete authentication


// 	UserDetailsService interface is provided by spring security. We must need to implement this interface.
// UserDetailsService interface hase ha method loaduserbyusername. We implement this methode. And retrive userdetails from databse. We return this to userdtails object and that object will take care by spring security